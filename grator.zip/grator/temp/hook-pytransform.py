datas = [(r"dist/obf/pytransform.key", "."), (r"dist/obf/license.lic", ".")]
binaries = [(r"dist/obf/_pytransform.*", ".")]